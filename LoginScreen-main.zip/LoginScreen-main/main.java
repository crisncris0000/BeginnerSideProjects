
public class main {

public static void main(String[] args) {
	
	LoginScreen screen = new LoginScreen();
}
}
